/*
 * Copyright (c) 2001 Matthew Feldt. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided the copyright notice above is
 * retained.
 *
 * THIS SOFTWARE IS PROVIDED ''AS IS'' AND WITHOUT ANY EXPRESSED OR
 * IMPLIED WARRANTIES.
 */

/**
 * ConvertTest.java
 *
 * @author Matthew Feldt <developer@feldt.com>
 * @version 0.7, 01/25/2005
 */

package com.feldt.metar.tools;

import com.feldt.metar.tools.Convert;

import junit.framework.TestCase;

public class ConvertTest extends TestCase {

	public void testCalculations() {
		assertEquals(0, Convert.fToC(32));
		assertEquals(212, Convert.cToF(100));
		assertEquals(115, Convert.ktToMph(100));
		assertEquals(51, Convert.ktToMps(100));
		assertEquals(160, Convert.smToKm(100));
//		assertEquals(160.0f, Convert.smToKm(100.0f));
	}
}
