/**
 * This package contains the classes representing the entities of RedisGraph module.
 */
package redis.clients.jedis.graph.entities;
