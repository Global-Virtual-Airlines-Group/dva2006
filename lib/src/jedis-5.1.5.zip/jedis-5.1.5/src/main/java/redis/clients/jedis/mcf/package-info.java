/**
 * This package contains the classes that are related to Active-Active cluster(s) and Multi-Cluster failover.
 */
package redis.clients.jedis.mcf;
