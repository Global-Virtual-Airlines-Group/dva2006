package redis.clients.jedis.json.commands;

public interface RedisJsonCommands extends RedisJsonV1Commands, RedisJsonV2Commands {

}
