package redis.clients.jedis.json.commands;

public interface RedisJsonPipelineCommands extends RedisJsonV1PipelineCommands, RedisJsonV2PipelineCommands {

}
