/**
 * This package contains the classes and interfaces related to RediSearch module.
 */
package redis.clients.jedis.search;
