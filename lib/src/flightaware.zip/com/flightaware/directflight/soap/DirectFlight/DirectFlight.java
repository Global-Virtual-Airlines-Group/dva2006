/**
 * DirectFlight.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flightaware.directflight.soap.DirectFlight;

public interface DirectFlight extends javax.xml.rpc.Service {

/**
 * FlightAware DirectFlight Web Service
 */
    public java.lang.String getDirectFlightSoapAddress();

    public com.flightaware.directflight.soap.DirectFlight.DirectFlightSoap getDirectFlightSoap() throws javax.xml.rpc.ServiceException;

    public com.flightaware.directflight.soap.DirectFlight.DirectFlightSoap getDirectFlightSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
