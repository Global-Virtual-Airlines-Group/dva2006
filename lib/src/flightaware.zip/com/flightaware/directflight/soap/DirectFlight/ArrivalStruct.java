/**
 * ArrivalStruct.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flightaware.directflight.soap.DirectFlight;

public class ArrivalStruct  implements java.io.Serializable {
    private java.lang.Integer next_offset;

    private com.flightaware.directflight.soap.DirectFlight.ArrivalFlightStruct[] arrivals;

    public ArrivalStruct() {
    }

    public ArrivalStruct(
           java.lang.Integer next_offset,
           com.flightaware.directflight.soap.DirectFlight.ArrivalFlightStruct[] arrivals) {
           this.next_offset = next_offset;
           this.arrivals = arrivals;
    }


    /**
     * Gets the next_offset value for this ArrivalStruct.
     * 
     * @return next_offset
     */
    public java.lang.Integer getNext_offset() {
        return next_offset;
    }


    /**
     * Sets the next_offset value for this ArrivalStruct.
     * 
     * @param next_offset
     */
    public void setNext_offset(java.lang.Integer next_offset) {
        this.next_offset = next_offset;
    }


    /**
     * Gets the arrivals value for this ArrivalStruct.
     * 
     * @return arrivals
     */
    public com.flightaware.directflight.soap.DirectFlight.ArrivalFlightStruct[] getArrivals() {
        return arrivals;
    }


    /**
     * Sets the arrivals value for this ArrivalStruct.
     * 
     * @param arrivals
     */
    public void setArrivals(com.flightaware.directflight.soap.DirectFlight.ArrivalFlightStruct[] arrivals) {
        this.arrivals = arrivals;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ArrivalStruct)) return false;
        ArrivalStruct other = (ArrivalStruct) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.next_offset==null && other.getNext_offset()==null) || 
             (this.next_offset!=null &&
              this.next_offset.equals(other.getNext_offset()))) &&
            ((this.arrivals==null && other.getArrivals()==null) || 
             (this.arrivals!=null &&
              java.util.Arrays.equals(this.arrivals, other.getArrivals())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNext_offset() != null) {
            _hashCode += getNext_offset().hashCode();
        }
        if (getArrivals() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrivals());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrivals(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ArrivalStruct.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://directflight.flightaware.com/soap/DirectFlight", "ArrivalStruct"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("next_offset");
        elemField.setXmlName(new javax.xml.namespace.QName("", "next_offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrivals");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arrivals"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://directflight.flightaware.com/soap/DirectFlight", "ArrivalFlightStruct"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
