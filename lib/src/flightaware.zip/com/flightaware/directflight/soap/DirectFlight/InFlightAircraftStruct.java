/**
 * InFlightAircraftStruct.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flightaware.directflight.soap.DirectFlight;

public class InFlightAircraftStruct  implements java.io.Serializable {
    private java.lang.String faFlightID;

    private java.lang.String ident;

    private java.lang.String prefix;

    private java.lang.String type;

    private java.lang.String suffix;

    private java.lang.String origin;

    private java.lang.String destination;

    private java.lang.String timeout;

    private java.lang.Integer timestamp;

    private java.lang.Integer departureTime;

    private java.lang.Integer firstPositionTime;

    private java.lang.Integer arrivalTime;

    private java.lang.Float longitude;

    private java.lang.Float latitude;

    private java.lang.Float lowLongitude;

    private java.lang.Float lowLatitude;

    private java.lang.Float highLongitude;

    private java.lang.Float highLatitude;

    private java.lang.Integer groundspeed;

    private java.lang.Integer altitude;

    private java.lang.Integer heading;

    private java.lang.String altitudeStatus;

    private java.lang.String updateType;

    private java.lang.String altitudeChange;

    public InFlightAircraftStruct() {
    }

    public InFlightAircraftStruct(
           java.lang.String faFlightID,
           java.lang.String ident,
           java.lang.String prefix,
           java.lang.String type,
           java.lang.String suffix,
           java.lang.String origin,
           java.lang.String destination,
           java.lang.String timeout,
           java.lang.Integer timestamp,
           java.lang.Integer departureTime,
           java.lang.Integer firstPositionTime,
           java.lang.Integer arrivalTime,
           java.lang.Float longitude,
           java.lang.Float latitude,
           java.lang.Float lowLongitude,
           java.lang.Float lowLatitude,
           java.lang.Float highLongitude,
           java.lang.Float highLatitude,
           java.lang.Integer groundspeed,
           java.lang.Integer altitude,
           java.lang.Integer heading,
           java.lang.String altitudeStatus,
           java.lang.String updateType,
           java.lang.String altitudeChange) {
           this.faFlightID = faFlightID;
           this.ident = ident;
           this.prefix = prefix;
           this.type = type;
           this.suffix = suffix;
           this.origin = origin;
           this.destination = destination;
           this.timeout = timeout;
           this.timestamp = timestamp;
           this.departureTime = departureTime;
           this.firstPositionTime = firstPositionTime;
           this.arrivalTime = arrivalTime;
           this.longitude = longitude;
           this.latitude = latitude;
           this.lowLongitude = lowLongitude;
           this.lowLatitude = lowLatitude;
           this.highLongitude = highLongitude;
           this.highLatitude = highLatitude;
           this.groundspeed = groundspeed;
           this.altitude = altitude;
           this.heading = heading;
           this.altitudeStatus = altitudeStatus;
           this.updateType = updateType;
           this.altitudeChange = altitudeChange;
    }


    /**
     * Gets the faFlightID value for this InFlightAircraftStruct.
     * 
     * @return faFlightID
     */
    public java.lang.String getFaFlightID() {
        return faFlightID;
    }


    /**
     * Sets the faFlightID value for this InFlightAircraftStruct.
     * 
     * @param faFlightID
     */
    public void setFaFlightID(java.lang.String faFlightID) {
        this.faFlightID = faFlightID;
    }


    /**
     * Gets the ident value for this InFlightAircraftStruct.
     * 
     * @return ident
     */
    public java.lang.String getIdent() {
        return ident;
    }


    /**
     * Sets the ident value for this InFlightAircraftStruct.
     * 
     * @param ident
     */
    public void setIdent(java.lang.String ident) {
        this.ident = ident;
    }


    /**
     * Gets the prefix value for this InFlightAircraftStruct.
     * 
     * @return prefix
     */
    public java.lang.String getPrefix() {
        return prefix;
    }


    /**
     * Sets the prefix value for this InFlightAircraftStruct.
     * 
     * @param prefix
     */
    public void setPrefix(java.lang.String prefix) {
        this.prefix = prefix;
    }


    /**
     * Gets the type value for this InFlightAircraftStruct.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this InFlightAircraftStruct.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }


    /**
     * Gets the suffix value for this InFlightAircraftStruct.
     * 
     * @return suffix
     */
    public java.lang.String getSuffix() {
        return suffix;
    }


    /**
     * Sets the suffix value for this InFlightAircraftStruct.
     * 
     * @param suffix
     */
    public void setSuffix(java.lang.String suffix) {
        this.suffix = suffix;
    }


    /**
     * Gets the origin value for this InFlightAircraftStruct.
     * 
     * @return origin
     */
    public java.lang.String getOrigin() {
        return origin;
    }


    /**
     * Sets the origin value for this InFlightAircraftStruct.
     * 
     * @param origin
     */
    public void setOrigin(java.lang.String origin) {
        this.origin = origin;
    }


    /**
     * Gets the destination value for this InFlightAircraftStruct.
     * 
     * @return destination
     */
    public java.lang.String getDestination() {
        return destination;
    }


    /**
     * Sets the destination value for this InFlightAircraftStruct.
     * 
     * @param destination
     */
    public void setDestination(java.lang.String destination) {
        this.destination = destination;
    }


    /**
     * Gets the timeout value for this InFlightAircraftStruct.
     * 
     * @return timeout
     */
    public java.lang.String getTimeout() {
        return timeout;
    }


    /**
     * Sets the timeout value for this InFlightAircraftStruct.
     * 
     * @param timeout
     */
    public void setTimeout(java.lang.String timeout) {
        this.timeout = timeout;
    }


    /**
     * Gets the timestamp value for this InFlightAircraftStruct.
     * 
     * @return timestamp
     */
    public java.lang.Integer getTimestamp() {
        return timestamp;
    }


    /**
     * Sets the timestamp value for this InFlightAircraftStruct.
     * 
     * @param timestamp
     */
    public void setTimestamp(java.lang.Integer timestamp) {
        this.timestamp = timestamp;
    }


    /**
     * Gets the departureTime value for this InFlightAircraftStruct.
     * 
     * @return departureTime
     */
    public java.lang.Integer getDepartureTime() {
        return departureTime;
    }


    /**
     * Sets the departureTime value for this InFlightAircraftStruct.
     * 
     * @param departureTime
     */
    public void setDepartureTime(java.lang.Integer departureTime) {
        this.departureTime = departureTime;
    }


    /**
     * Gets the firstPositionTime value for this InFlightAircraftStruct.
     * 
     * @return firstPositionTime
     */
    public java.lang.Integer getFirstPositionTime() {
        return firstPositionTime;
    }


    /**
     * Sets the firstPositionTime value for this InFlightAircraftStruct.
     * 
     * @param firstPositionTime
     */
    public void setFirstPositionTime(java.lang.Integer firstPositionTime) {
        this.firstPositionTime = firstPositionTime;
    }


    /**
     * Gets the arrivalTime value for this InFlightAircraftStruct.
     * 
     * @return arrivalTime
     */
    public java.lang.Integer getArrivalTime() {
        return arrivalTime;
    }


    /**
     * Sets the arrivalTime value for this InFlightAircraftStruct.
     * 
     * @param arrivalTime
     */
    public void setArrivalTime(java.lang.Integer arrivalTime) {
        this.arrivalTime = arrivalTime;
    }


    /**
     * Gets the longitude value for this InFlightAircraftStruct.
     * 
     * @return longitude
     */
    public java.lang.Float getLongitude() {
        return longitude;
    }


    /**
     * Sets the longitude value for this InFlightAircraftStruct.
     * 
     * @param longitude
     */
    public void setLongitude(java.lang.Float longitude) {
        this.longitude = longitude;
    }


    /**
     * Gets the latitude value for this InFlightAircraftStruct.
     * 
     * @return latitude
     */
    public java.lang.Float getLatitude() {
        return latitude;
    }


    /**
     * Sets the latitude value for this InFlightAircraftStruct.
     * 
     * @param latitude
     */
    public void setLatitude(java.lang.Float latitude) {
        this.latitude = latitude;
    }


    /**
     * Gets the lowLongitude value for this InFlightAircraftStruct.
     * 
     * @return lowLongitude
     */
    public java.lang.Float getLowLongitude() {
        return lowLongitude;
    }


    /**
     * Sets the lowLongitude value for this InFlightAircraftStruct.
     * 
     * @param lowLongitude
     */
    public void setLowLongitude(java.lang.Float lowLongitude) {
        this.lowLongitude = lowLongitude;
    }


    /**
     * Gets the lowLatitude value for this InFlightAircraftStruct.
     * 
     * @return lowLatitude
     */
    public java.lang.Float getLowLatitude() {
        return lowLatitude;
    }


    /**
     * Sets the lowLatitude value for this InFlightAircraftStruct.
     * 
     * @param lowLatitude
     */
    public void setLowLatitude(java.lang.Float lowLatitude) {
        this.lowLatitude = lowLatitude;
    }


    /**
     * Gets the highLongitude value for this InFlightAircraftStruct.
     * 
     * @return highLongitude
     */
    public java.lang.Float getHighLongitude() {
        return highLongitude;
    }


    /**
     * Sets the highLongitude value for this InFlightAircraftStruct.
     * 
     * @param highLongitude
     */
    public void setHighLongitude(java.lang.Float highLongitude) {
        this.highLongitude = highLongitude;
    }


    /**
     * Gets the highLatitude value for this InFlightAircraftStruct.
     * 
     * @return highLatitude
     */
    public java.lang.Float getHighLatitude() {
        return highLatitude;
    }


    /**
     * Sets the highLatitude value for this InFlightAircraftStruct.
     * 
     * @param highLatitude
     */
    public void setHighLatitude(java.lang.Float highLatitude) {
        this.highLatitude = highLatitude;
    }


    /**
     * Gets the groundspeed value for this InFlightAircraftStruct.
     * 
     * @return groundspeed
     */
    public java.lang.Integer getGroundspeed() {
        return groundspeed;
    }


    /**
     * Sets the groundspeed value for this InFlightAircraftStruct.
     * 
     * @param groundspeed
     */
    public void setGroundspeed(java.lang.Integer groundspeed) {
        this.groundspeed = groundspeed;
    }


    /**
     * Gets the altitude value for this InFlightAircraftStruct.
     * 
     * @return altitude
     */
    public java.lang.Integer getAltitude() {
        return altitude;
    }


    /**
     * Sets the altitude value for this InFlightAircraftStruct.
     * 
     * @param altitude
     */
    public void setAltitude(java.lang.Integer altitude) {
        this.altitude = altitude;
    }


    /**
     * Gets the heading value for this InFlightAircraftStruct.
     * 
     * @return heading
     */
    public java.lang.Integer getHeading() {
        return heading;
    }


    /**
     * Sets the heading value for this InFlightAircraftStruct.
     * 
     * @param heading
     */
    public void setHeading(java.lang.Integer heading) {
        this.heading = heading;
    }


    /**
     * Gets the altitudeStatus value for this InFlightAircraftStruct.
     * 
     * @return altitudeStatus
     */
    public java.lang.String getAltitudeStatus() {
        return altitudeStatus;
    }


    /**
     * Sets the altitudeStatus value for this InFlightAircraftStruct.
     * 
     * @param altitudeStatus
     */
    public void setAltitudeStatus(java.lang.String altitudeStatus) {
        this.altitudeStatus = altitudeStatus;
    }


    /**
     * Gets the updateType value for this InFlightAircraftStruct.
     * 
     * @return updateType
     */
    public java.lang.String getUpdateType() {
        return updateType;
    }


    /**
     * Sets the updateType value for this InFlightAircraftStruct.
     * 
     * @param updateType
     */
    public void setUpdateType(java.lang.String updateType) {
        this.updateType = updateType;
    }


    /**
     * Gets the altitudeChange value for this InFlightAircraftStruct.
     * 
     * @return altitudeChange
     */
    public java.lang.String getAltitudeChange() {
        return altitudeChange;
    }


    /**
     * Sets the altitudeChange value for this InFlightAircraftStruct.
     * 
     * @param altitudeChange
     */
    public void setAltitudeChange(java.lang.String altitudeChange) {
        this.altitudeChange = altitudeChange;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InFlightAircraftStruct)) return false;
        InFlightAircraftStruct other = (InFlightAircraftStruct) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.faFlightID==null && other.getFaFlightID()==null) || 
             (this.faFlightID!=null &&
              this.faFlightID.equals(other.getFaFlightID()))) &&
            ((this.ident==null && other.getIdent()==null) || 
             (this.ident!=null &&
              this.ident.equals(other.getIdent()))) &&
            ((this.prefix==null && other.getPrefix()==null) || 
             (this.prefix!=null &&
              this.prefix.equals(other.getPrefix()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.suffix==null && other.getSuffix()==null) || 
             (this.suffix!=null &&
              this.suffix.equals(other.getSuffix()))) &&
            ((this.origin==null && other.getOrigin()==null) || 
             (this.origin!=null &&
              this.origin.equals(other.getOrigin()))) &&
            ((this.destination==null && other.getDestination()==null) || 
             (this.destination!=null &&
              this.destination.equals(other.getDestination()))) &&
            ((this.timeout==null && other.getTimeout()==null) || 
             (this.timeout!=null &&
              this.timeout.equals(other.getTimeout()))) &&
            ((this.timestamp==null && other.getTimestamp()==null) || 
             (this.timestamp!=null &&
              this.timestamp.equals(other.getTimestamp()))) &&
            ((this.departureTime==null && other.getDepartureTime()==null) || 
             (this.departureTime!=null &&
              this.departureTime.equals(other.getDepartureTime()))) &&
            ((this.firstPositionTime==null && other.getFirstPositionTime()==null) || 
             (this.firstPositionTime!=null &&
              this.firstPositionTime.equals(other.getFirstPositionTime()))) &&
            ((this.arrivalTime==null && other.getArrivalTime()==null) || 
             (this.arrivalTime!=null &&
              this.arrivalTime.equals(other.getArrivalTime()))) &&
            ((this.longitude==null && other.getLongitude()==null) || 
             (this.longitude!=null &&
              this.longitude.equals(other.getLongitude()))) &&
            ((this.latitude==null && other.getLatitude()==null) || 
             (this.latitude!=null &&
              this.latitude.equals(other.getLatitude()))) &&
            ((this.lowLongitude==null && other.getLowLongitude()==null) || 
             (this.lowLongitude!=null &&
              this.lowLongitude.equals(other.getLowLongitude()))) &&
            ((this.lowLatitude==null && other.getLowLatitude()==null) || 
             (this.lowLatitude!=null &&
              this.lowLatitude.equals(other.getLowLatitude()))) &&
            ((this.highLongitude==null && other.getHighLongitude()==null) || 
             (this.highLongitude!=null &&
              this.highLongitude.equals(other.getHighLongitude()))) &&
            ((this.highLatitude==null && other.getHighLatitude()==null) || 
             (this.highLatitude!=null &&
              this.highLatitude.equals(other.getHighLatitude()))) &&
            ((this.groundspeed==null && other.getGroundspeed()==null) || 
             (this.groundspeed!=null &&
              this.groundspeed.equals(other.getGroundspeed()))) &&
            ((this.altitude==null && other.getAltitude()==null) || 
             (this.altitude!=null &&
              this.altitude.equals(other.getAltitude()))) &&
            ((this.heading==null && other.getHeading()==null) || 
             (this.heading!=null &&
              this.heading.equals(other.getHeading()))) &&
            ((this.altitudeStatus==null && other.getAltitudeStatus()==null) || 
             (this.altitudeStatus!=null &&
              this.altitudeStatus.equals(other.getAltitudeStatus()))) &&
            ((this.updateType==null && other.getUpdateType()==null) || 
             (this.updateType!=null &&
              this.updateType.equals(other.getUpdateType()))) &&
            ((this.altitudeChange==null && other.getAltitudeChange()==null) || 
             (this.altitudeChange!=null &&
              this.altitudeChange.equals(other.getAltitudeChange())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFaFlightID() != null) {
            _hashCode += getFaFlightID().hashCode();
        }
        if (getIdent() != null) {
            _hashCode += getIdent().hashCode();
        }
        if (getPrefix() != null) {
            _hashCode += getPrefix().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getSuffix() != null) {
            _hashCode += getSuffix().hashCode();
        }
        if (getOrigin() != null) {
            _hashCode += getOrigin().hashCode();
        }
        if (getDestination() != null) {
            _hashCode += getDestination().hashCode();
        }
        if (getTimeout() != null) {
            _hashCode += getTimeout().hashCode();
        }
        if (getTimestamp() != null) {
            _hashCode += getTimestamp().hashCode();
        }
        if (getDepartureTime() != null) {
            _hashCode += getDepartureTime().hashCode();
        }
        if (getFirstPositionTime() != null) {
            _hashCode += getFirstPositionTime().hashCode();
        }
        if (getArrivalTime() != null) {
            _hashCode += getArrivalTime().hashCode();
        }
        if (getLongitude() != null) {
            _hashCode += getLongitude().hashCode();
        }
        if (getLatitude() != null) {
            _hashCode += getLatitude().hashCode();
        }
        if (getLowLongitude() != null) {
            _hashCode += getLowLongitude().hashCode();
        }
        if (getLowLatitude() != null) {
            _hashCode += getLowLatitude().hashCode();
        }
        if (getHighLongitude() != null) {
            _hashCode += getHighLongitude().hashCode();
        }
        if (getHighLatitude() != null) {
            _hashCode += getHighLatitude().hashCode();
        }
        if (getGroundspeed() != null) {
            _hashCode += getGroundspeed().hashCode();
        }
        if (getAltitude() != null) {
            _hashCode += getAltitude().hashCode();
        }
        if (getHeading() != null) {
            _hashCode += getHeading().hashCode();
        }
        if (getAltitudeStatus() != null) {
            _hashCode += getAltitudeStatus().hashCode();
        }
        if (getUpdateType() != null) {
            _hashCode += getUpdateType().hashCode();
        }
        if (getAltitudeChange() != null) {
            _hashCode += getAltitudeChange().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InFlightAircraftStruct.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://directflight.flightaware.com/soap/DirectFlight", "InFlightAircraftStruct"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("faFlightID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "faFlightID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ident");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ident"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prefix");
        elemField.setXmlName(new javax.xml.namespace.QName("", "prefix"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suffix");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suffix"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("origin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "origin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("destination");
        elemField.setXmlName(new javax.xml.namespace.QName("", "destination"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "timeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timestamp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "timestamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("departureTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "departureTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstPositionTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "firstPositionTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrivalTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arrivalTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("longitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "longitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("latitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "latitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowLongitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lowLongitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowLatitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lowLatitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("highLongitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "highLongitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("highLatitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "highLatitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groundspeed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groundspeed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("altitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "altitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("heading");
        elemField.setXmlName(new javax.xml.namespace.QName("", "heading"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("altitudeStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "altitudeStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("altitudeChange");
        elemField.setXmlName(new javax.xml.namespace.QName("", "altitudeChange"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
