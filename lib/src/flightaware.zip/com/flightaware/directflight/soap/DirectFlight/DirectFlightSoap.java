/**
 * DirectFlightSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flightaware.directflight.soap.DirectFlight;

public interface DirectFlightSoap extends java.rmi.Remote {

    /**
     * <p>FlightInfo returns information about flights for a specific
     * tail number (e.g., <strong>N12345</strong>) or ICAO airline and flight
     * 
     * number (e.g., <strong>SWA2558</strong>) and the maximum number of
     * flights to be returned.  Flight information will be returned from
     * newest to old
     * est with the oldest not being more than 3-4 days in the past.</p>
     * <p>Times are in integer seconds-since-1970 (UNIX epoch) time, except
     * for estimated time enroute, which is in hours and minutes.</p>
     */
    public com.flightaware.directflight.soap.DirectFlight.FlightInfoStruct flightInfo(java.lang.String ident, int howMany) throws java.rmi.RemoteException;

    /**
     * InFlightInfo looks up a specific tail number (e.g., <strong>N12345</strong>)
     * or ICAO airline and flight number (e.g., <strong>SWA2558</strong>)
     * and returns current position/direction/speed information.  It is only
     * useful for airborne flights.
     */
    public com.flightaware.directflight.soap.DirectFlight.InFlightAircraftStruct inFlightInfo(java.lang.String ident) throws java.rmi.RemoteException;

    /**
     * <p>GetLastTrack looks up a flight by specific tail number (e.g.,
     * <strong>N12345</strong>) or ICAO airline and flight number (e.g.,
     * <strong>SWA2558</strong>).  It returns the track log from the current
     * IFR flight or, if the aircraft is not airborne, the most recent IFR
     * flight.  It returns an array of positions, with each including the
     * timestamp, longitude, latitude groundspeed, altitude, altitudestatus,
     * updatetype, and altitudechange.  Altitude is in hundreds of feet or
     * Flight Level where appropriate, see http://flightaware.com/about/faq.rvt#flightLevel.
     * Also included altitude status, update type, and altitude change
     * <p>Altitude status is 'C' when the flight is more than 200 feet away
     * from its ATC-assigned altitude.  (For example, the aircraft is transitioning
     * to its assigned altitude.)  Altitude change is 'C' if the aircraft
     * is climbing (compared to the previous position reported), 'D' for
     * descending, and empty if it is level.  This happens for VFR flights
     * with flight following, among other things.  Timestamp is integer seconds-since-1970.
     * </p>
     */
    public com.flightaware.directflight.soap.DirectFlight.TrackStruct[] getLastTrack(java.lang.String ident) throws java.rmi.RemoteException;

    /**
     * Search searches data on all airborne aircraft to find ones
     * matching the search query.  Query parameters include a latitude/longitude
     * box, aircraft ident with wildcards, type with wildcards, prefix, suffix,
     * origin airport, destination airport, origin or destination airport,
     * groundspeed, and altitude.  It takes search terms in a single string
     * comprising "-key value" pairs and returns an array of flight structures.
     * <p>
     * Keys include:
     * <ul>
     *  <li>-prefix</li>
     *  <li>-type</li>
     *  <li>-suffix</li>
     *  <li>-idents</li>
     *  <li>-destination</li>
     *  <li>-origin
     *  <li>-originOrDestination</li>
     *  <li>-aboveAltitude</li>
     *  <li>-belowAltitude</li>
     *  <li>-aboveGroundspeed</li>
     *  <li>-belowGroundspeed</li>
     *  <li>-latlong</li>
     * </ul>
     * 
     * <p>
     *  To search for all aircraft below ten-thousand feet with a groundspeed
     * over 
     *  200 kts:
     *  <div class="indent">
     *      -belowAltitude 100 -aboveGroundspeed 200
     *  </div>
     * </p>
     * 
     * <p>
     * To search for all in-air Boeing 777s:
     *  <div class="indent">
     *     -type B77*
     *  </div> 
     * </p>
     * 
     * <p>
     * To search for all aircraft heading to Los Angeles International Airport
     * (LAX) that are "heavy" aircraft:
     *  <div class="indent">
     *     -destination LAX -prefix H
     *  </div>
     * </p>
     * 
     * <p>
     * To search for all Continental Airlines flights in Boeing 737s
     *  <div class="indent">
     *     -idents COA* -type B73*
     *  <?div>
     * </p>
     */
    public com.flightaware.directflight.soap.DirectFlight.InFlightStruct search(java.lang.String query, int howMany, int offset) throws java.rmi.RemoteException;

    /**
     * SearchCount works like Search but returns a count of matching
     * flights rather than information about each flight.
     */
    public int searchCount(java.lang.String query) throws java.rmi.RemoteException;

    /**
     * <p>Scheduled returns information about scheduled flights (technically,
     * filed IFR flights) for a specified airport and a maximum number of
     * flights to be returned.  Scheduled flights are returned from soonest
     * to furthest in the future to depart.</p>
     * 
     * <p>
     *  The <strong>airport</strong> argument must be the ICAO airport ID
     * (e.g., KLAX, KSFO, KIAH, KHOU, KJFK, KEWR, KORD, KATL, etc.
     * </p>
     * 
     * <p>
     *  The <strong>howMany</strong> argument must be an integer value less
     * than or equal to 15 and determines the number of results.
     * </p>
     * 
     * <p>
     *  The <strong>offset</strong> argument must be an integer value of
     * the offset row count you want the search to start at.  Most requests
     * should be 0.
     * </p>
     * 
     * <p>
     *  The <strong>filter</strong> argument can be &quot;ga&quot; or &quot;airline&quot;
     * to only show GA or Airline traffic, respectively, or null/empty to
     * show all traffic.
     * </p>
     * 
     * <p>
     *  The <strong>next_offset</strong> value returned advises an application
     * of the next offset to use (if more data is available).
     * </p>
     * 
     * <p>Times returned are UNIX epoch (integer seconds since 1970) format.</p>
     */
    public com.flightaware.directflight.soap.DirectFlight.ScheduledStruct scheduled(java.lang.String airport, int howMany, java.lang.String filter, int offset) throws java.rmi.RemoteException;

    /**
     * <p>Departed returns information about already departed flights
     * for a specified airport and maximum number of flights to be returned.
     * Departed flights are returned in order from most recently to least
     * recently departed.</p>
     * 
     * <p>
     *  The <strong>airport</strong> argument must be the ICAO airport ID
     * (e.g., KLAX, KSFO, KIAH, KHOU, KJFK, KEWR, KORD, KATL, etc.
     * </p>
     * 
     * <p>
     *  The <strong>howMany</strong> argument must be an integer value less
     * than or equal to 15 and determines the number of results.
     * </p>
     * 
     * <p>
     *  The <strong>offset</strong> argument must be an integer value of
     * the offset row count you want the search to start at.  Most requests
     * should be 0.
     * </p>
     * 
     * <p>
     *  The <strong>filter</strong> argument can be &quot;ga&quot; or &quot;airline&quot;
     * to only show GA or Airline traffic, respectively, or null/empty to
     * show all traffic.
     * </p>
     * 
     * <p>
     *  The <strong>next_offset</strong> value returned advises an application
     * of the next offset to use (if more data is available).
     * </p>
     */
    public com.flightaware.directflight.soap.DirectFlight.DepartureStruct departed(java.lang.String airport, int howMany, java.lang.String filter, int offset) throws java.rmi.RemoteException;

    /**
     * <p>Enroute returns information about flights already in the
     * air for the specified airport and maximum number of flights to be
     * returned.  Enroute flights are returned from soonest estimated arrival
     * to least soon estimated arrival.</p>
     * 
     * <p>
     *  The <strong>airport</strong> argument must be the ICAO airport ID
     * (e.g., KLAX, KSFO, KIAH, KHOU, KJFK, KEWR, KORD, KATL, etc.
     * </p>
     * 
     * <p>
     *  The <strong>howMany</strong> argument must be an integer value less
     * than or equal to 15 and determines the number of results.
     * </p>
     * 
     * <p>
     *  The <strong>offset</strong> argument must be an integer value of
     * the offset row count you want the search to start at.  Most requests
     * should be 0.
     * </p>
     * 
     * <p>
     *  The <strong>filter</strong> argument can be &quot;ga&quot; or &quot;airline&quot;
     * to only show GA or Airline traffic, respectively, or null/empty to
     * show all traffic.
     * </p>
     * 
     * <p>
     *  The <strong>next_offset</strong> value returned advises an application
     * of the next offset to use (if more data is available).
     * </p>
     */
    public com.flightaware.directflight.soap.DirectFlight.EnrouteStruct enroute(java.lang.String airport, int howMany, java.lang.String filter, int offset) throws java.rmi.RemoteException;

    /**
     * <p>
     *  The <strong>fleet</strong> argument must be an ICAO prefix (e.g.,
     * COA, DAL, UAL, OPT, etc.)
     * </p>
     *          
     * <p>
     *  The <strong>howMany</strong> argument must be an integer value less
     * than or equal to 15 and determines the number of results.
     * </p>
     *      
     * <p>
     *  The <strong>offset</strong> argument must be an integer value of
     * the offset row count you want the search to start at.  Most requests
     * should be 0.
     * </p>
     * 
     * <p>
     *  The <strong>next_offset</strong> value returned advises an application
     * of the next offset to use (if more data is available).
     * </p>
     */
    public com.flightaware.directflight.soap.DirectFlight.ArrivalStruct fleetArrived(java.lang.String fleet, int howMany, int offset) throws java.rmi.RemoteException;

    /**
     * <p>Arrived returns information about flights that have recently
     * arrived for the specified airport and maximum number of flights to
     * be returned.  Flights are returned from most to least recent.</p>
     * <p>
     *  The <strong>airport</strong> argument must be the ICAO airport ID
     * (e.g., KLAX, KSFO, KIAH, KHOU, KJFK, KEWR, KORD, KATL, etc.
     * </p>
     * 
     * <p>
     *  The <strong>howMany</strong> argument must be an integer value less
     * than or equal to 15 and determines the number of results.
     * </p>
     * 
     * <p>
     *  The <strong>offset</strong> argument must be an integer value of
     * the offset row count you want the search to start at.  Most requests
     * should be 0.
     * </p>
     * 
     * <p>
     *  The <strong>filter</strong> argument can be &quot;ga&quot; or &quot;airline&quot;
     * to only show GA or Airline traffic, respectively, or null/empty to
     * show all traffic.
     * </p>
     * 
     * <p>
     *  The <strong>next_offset</strong> value returned advises an application
     * of the next offset to use (if more data is available).
     * </p>
     */
    public com.flightaware.directflight.soap.DirectFlight.ArrivalStruct arrived(java.lang.String airport, int howMany, java.lang.String filter, int offset) throws java.rmi.RemoteException;

    /**
     * AllAirports returns the ICAO airport IDs of all known airports.
     */
    public java.lang.String[] allAirports() throws java.rmi.RemoteException;

    /**
     * ZipcodeInfo returns information about a five-digit zipcode.
     * Of particular importance is latitude and longitude.
     */
    public com.flightaware.directflight.soap.DirectFlight.ZipcodeInfoStruct zipcodeInfo(java.lang.String zipcode) throws java.rmi.RemoteException;

    /**
     * AirportInfo returns information about an airport given an ICAO
     * airport code such as KLAX, KSFO, KORD, KIAH, O07, etc.  Data returned
     * includes name (Houston Intercontinental Airport), location (typically
     * city and state), latitude and longitude.
     */
    public com.flightaware.directflight.soap.DirectFlight.AirportInfoStruct airportInfo(java.lang.String airportCode) throws java.rmi.RemoteException;

    /**
     * TailOwner returns information about an the owner of an aircraft,
     * given a flight number or N-number.  Data returned includes owner's
     * name, location (typically city and state), and website, if any.
     */
    public com.flightaware.directflight.soap.DirectFlight.TailOwnerStruct tailOwner(java.lang.String ident) throws java.rmi.RemoteException;

    /**
     * RoutesBetweenAirports returns information about assigned IFR
     * routings between two airports.  For each known routing, the route,
     * number of times that route has been assigned and the filed altitude
     * are returned.
     */
    public com.flightaware.directflight.soap.DirectFlight.RoutesBetweenAirportsStruct[] routesBetweenAirports(java.lang.String origin, java.lang.String destination) throws java.rmi.RemoteException;

    /**
     * Given an aircraft type string such as GALX, AircraftType returns
     * information about that type, comprising the manufacturer (for instance,
     * "IAI"), type (for instance, "Gulfstream G200"), and description (like
     * "twin-jet").
     */
    public com.flightaware.directflight.soap.DirectFlight.AircraftTypeStruct aircraftType(java.lang.String type) throws java.rmi.RemoteException;

    /**
     * Given an airport, returns integer values on the number of aircraft
     * scheduled or actually en route or departing from the airport.  Scheduled
     * arrival is a non-airborne flight that is scheduled to the airport
     * in question.
     */
    public com.flightaware.directflight.soap.DirectFlight.CountAirportOperationsStruct countAirportOperations(java.lang.String airport) throws java.rmi.RemoteException;

    /**
     * Given an aircraft identification, returns 1 if the aircraft
     * is blocked from public tracking, 0 if it is not.
     */
    public int blockIdentCheck(java.lang.String ident) throws java.rmi.RemoteException;

    /**
     * Given an airport, return the METAR weather info, if available.
     */
    public java.lang.String METAR(java.lang.String airport) throws java.rmi.RemoteException;

    /**
     * Given an airport, return the terminal area forecast, if available.
     */
    public java.lang.String TAF(java.lang.String airport) throws java.rmi.RemoteException;

    /**
     * Given an airport, return the terminal area forecast, if available.
     */
    public com.flightaware.directflight.soap.DirectFlight.TafStruct NTAF(java.lang.String airport) throws java.rmi.RemoteException;

    /**
     * Given two latitudes and longitudes, lat1 lon1 lat2 and lon2,
     * respectively, determine the great circle distance between those positions
     * in miles.
     */
    public int latLongsToDistance(float lat1, float lon1, float lat2, float lon2) throws java.rmi.RemoteException;

    /**
     * Given two latitudes and longitudes, lat1 lon1 lat2 and lon2,
     * respectively, calculate and return the initial compass heading (where
     * 360 is North) from position one to position two. Quite accurate for
     * relatively short distances but since it assumes the earth is a sphere
     * rather than on irregular oblate sphereoid may be inaccurate for flights
     * around a good chunk of the world, etc.
     */
    public int latLongsToHeading(float lat1, float lon1, float lat2, float lon2) throws java.rmi.RemoteException;

    /**
     * This function will return a base64 encoded GIF (with the height
     * and width as specified in pixels) of the most recent
     * 	(past or current) flight of a specified ident.  This service is in
     * beta.  Future versions will allow viewing of past
     * 	flights, configuring nexrad, and configuring zoom.
     */
    public java.lang.String mapFlight_Beta(java.lang.String ident, int mapHeight, int mapWidth) throws java.rmi.RemoteException;
}
