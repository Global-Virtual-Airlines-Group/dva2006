/**
 * FlightXML2.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flightaware.flightxml.soap.FlightXML2;

public interface FlightXML2 extends javax.xml.rpc.Service {

/**
 * FlightXML2 Web Services
 */
    public java.lang.String getFlightXML2SoapAddress();

    public com.flightaware.flightxml.soap.FlightXML2.FlightXML2Soap getFlightXML2Soap() throws javax.xml.rpc.ServiceException;

    public com.flightaware.flightxml.soap.FlightXML2.FlightXML2Soap getFlightXML2Soap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
