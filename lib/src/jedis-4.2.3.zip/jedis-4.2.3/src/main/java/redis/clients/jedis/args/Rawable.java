package redis.clients.jedis.args;

public interface Rawable {

  byte[] getRaw();
}
