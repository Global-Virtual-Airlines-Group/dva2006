/*
 * This package contains the classes related to Aggregation commands in RediSearch module.
 */
package redis.clients.jedis.search.aggr;
