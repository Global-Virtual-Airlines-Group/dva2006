/*
 * This package contains the classes related to RediSearch module.
 */
package redis.clients.jedis.search;
